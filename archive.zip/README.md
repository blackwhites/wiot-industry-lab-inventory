# WIoT Industry Lab Inventory

Watson IoT Industry Lab Inventory app based on the Meteor Blaze Tutorial: https://www.meteor.com/tutorials/blaze/creating-an-app

## Run locally

1. Install meteor: https://www.meteor.com/install
2. Cd to the project base directory
3. run `meteor npm install`
4. run `meteor`
5. Open your browser at `http://localhost:3000/`

## Run on Bluemix

1. Create a Node.js app on Bluemix
2. Add a "Compose for MongoDB" Service to it
3. Follow instructions on https://github.com/tadasdanielius/cf-meteor-pb-buildback

